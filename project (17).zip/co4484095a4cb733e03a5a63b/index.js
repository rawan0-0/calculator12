

let result = document.getElementById("result");

function addToResult(value) {
  
  result.value += value;
  
}
function clearResult() {
  
  result.value = "";
}
function calculate() { try
}

result.value = eval(result.value);
} Catch (error) {
  result.value = "Error";
}
}
  